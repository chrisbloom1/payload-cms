# Your Framer Components

Exported by [Proofly React Export](https://proofly.ae/docs/react-export) on 2026-04-28.

## Install

```bash
npm install @proofly-framer/ui@https://registry.proofly.ae/ui/93bd9730-02e5-4beb-ba6a-885a45ba1894.tgz
```

## Your components (26)

```tsx
import { Brandsintroanimation, Faqbrands, Faqproviders, Animationweb, Animationtree, Mockupterms, Animationmap, Animationproducts, Stepsslider, Button3, Pricing, Pricingmatrix, Sepline, SECTIONHERONEW, InputBox, BloomChatBox, Prompt2, SendButton, SECTIONHEROTEMP, Logomatrix, Wehelpmake, Button4, Navigation2, Brandsslider2, Wehelpmake2, Imputslider } from '@proofly-framer/ui'
```

### Brandsintroanimation

**Usage:**

```tsx
<Brandsintroanimation />
```

### Faqbrands

**Variants:** `"Closed" | "Open" | "last-closed" | "last-open"`

**Props:**

| Name | Type | Required |
|---|---|---|
| `variant` | `FaqbrandsVariant | Partial<Record<"base" | "sm" | "md" | "lg" | "xl", Faqbran...` |  |
| `question` | `string` |  |
| `answer` | `string` |  |
| `click` | `(...args: any[]) => void` |  |
| `backgroundColor` | `string` |  |
| `textColor` | `string` |  |

**Usage:**

```tsx
<Faqbrands
  variant="Closed"
  question="…"
  answer="…"
  backgroundColor="…"
  textColor="…"
/>
```

_Variants also accept a per-breakpoint object, e.g._ `variant={{ base: '…', lg: '…' }}`

### Faqproviders

**Variants:** `"Closed" | "Open" | "last-closed" | "last-open"`

**Props:**

| Name | Type | Required |
|---|---|---|
| `variant` | `FaqprovidersVariant | Partial<Record<"base" | "sm" | "md" | "lg" | "xl", Faqp...` |  |
| `question` | `string` |  |
| `answer` | `string` |  |
| `click` | `(...args: any[]) => void` |  |
| `backgroundColor` | `string` |  |
| `textColor` | `string` |  |

**Usage:**

```tsx
<Faqproviders
  variant="Closed"
  question="…"
  answer="…"
  backgroundColor="…"
  textColor="…"
/>
```

_Variants also accept a per-breakpoint object, e.g._ `variant={{ base: '…', lg: '…' }}`

### Animationweb

**Usage:**

```tsx
<Animationweb />
```

### Animationtree

**Usage:**

```tsx
<Animationtree />
```

### Mockupterms

**Usage:**

```tsx
<Mockupterms />
```

### Animationmap

**Variants:** `"Variant 1" | "Variant 2" | "Variant 3" | "Variant 4"`

**Props:**

| Name | Type | Required |
|---|---|---|
| `variant` | `AnimationmapVariant | Partial<Record<"base" | "sm" | "md" | "lg" | "xl", Anim...` |  |

**Usage:**

```tsx
<Animationmap
  variant="Variant 1"
/>
```

_Variants also accept a per-breakpoint object, e.g._ `variant={{ base: '…', lg: '…' }}`

### Animationproducts

**Variants:** `"Variant 1" | "Variant 2"`

**Props:**

| Name | Type | Required |
|---|---|---|
| `variant` | `AnimationproductsVariant | Partial<Record<"base" | "sm" | "md" | "lg" | "xl",...` |  |

**Usage:**

```tsx
<Animationproducts
  variant="Variant 1"
/>
```

_Variants also accept a per-breakpoint object, e.g._ `variant={{ base: '…', lg: '…' }}`

### Stepsslider

**Variants:** `"Variant 1" | "Variant 2" | "Variant 3" | "Variant 4" | "Variant 5" | "Variant 6" | "Variant 7" | "Variant 8" | "PHONE"`

**Props:**

| Name | Type | Required |
|---|---|---|
| `variant` | `StepssliderVariant | Partial<Record<"base" | "sm" | "md" | "lg" | "xl", Steps...` |  |

**Usage:**

```tsx
<Stepsslider
  variant="Variant 1"
/>
```

_Variants also accept a per-breakpoint object, e.g._ `variant={{ base: '…', lg: '…' }}`

### Button3

**Variants:** `"Default" | "Loading" | "Disabled" | "Success" | "Error"`

**Props:**

| Name | Type | Required |
|---|---|---|
| `variant` | `Button3Variant | Partial<Record<"base" | "sm" | "md" | "lg" | "xl", Button3Va...` |  |

**Usage:**

```tsx
<Button3
  variant="Default"
/>
```

_Variants also accept a per-breakpoint object, e.g._ `variant={{ base: '…', lg: '…' }}`

### Pricing

**Usage:**

```tsx
<Pricing />
```

### Pricingmatrix

**Variants:** `"gradient" | "single color"`

**Props:**

| Name | Type | Required |
|---|---|---|
| `variant` | `PricingmatrixVariant | Partial<Record<"base" | "sm" | "md" | "lg" | "xl", Pri...` |  |
| `color` | `string` |  |

**Usage:**

```tsx
<Pricingmatrix
  variant="gradient"
  color="…"
/>
```

_Variants also accept a per-breakpoint object, e.g._ `variant={{ base: '…', lg: '…' }}`

### Sepline

**Variants:** `"gradient" | "single color"`

**Props:**

| Name | Type | Required |
|---|---|---|
| `variant` | `SeplineVariant | Partial<Record<"base" | "sm" | "md" | "lg" | "xl", SeplineVa...` |  |
| `color` | `string` |  |

**Usage:**

```tsx
<Sepline
  variant="gradient"
  color="…"
/>
```

_Variants also accept a per-breakpoint object, e.g._ `variant={{ base: '…', lg: '…' }}`

### SECTIONHERONEW

**Props:**

| Name | Type | Required |
|---|---|---|
| `placeholder` | `string` |  |
| `placeholderColor` | `string` |  |
| `textColor` | `string` |  |
| `font` | `any` |  |
| `fontSize` | `number` |  |
| `textareaBG` | `string` |  |
| `borderColor` | `string` |  |
| `radius` | `number` |  |
| `buttonBG` | `string` |  |
| `buttonTextColor` | `string` |  |
| `height` | `number` |  |

**Usage:**

```tsx
<SECTIONHERONEW
  placeholder="…"
  placeholderColor="…"
  textColor="…"
  fontSize={0}
  textareaBG="…"
  borderColor="…"
  radius={0}
  buttonBG="…"
  buttonTextColor="…"
  height={0}
/>
```

### InputBox

**Usage:**

```tsx
<InputBox />
```

### BloomChatBox

**Usage:**

```tsx
<BloomChatBox />
```

### Prompt2

**Usage:**

```tsx
<Prompt2 />
```

### SendButton

**Usage:**

```tsx
<SendButton />
```

### SECTIONHEROTEMP

**Props:**

| Name | Type | Required |
|---|---|---|
| `placeholder` | `string` |  |
| `placeholderColor` | `string` |  |
| `textColor` | `string` |  |
| `font` | `any` |  |
| `fontSize` | `number` |  |
| `textareaBG` | `string` |  |
| `borderColor` | `string` |  |
| `radius` | `number` |  |
| `buttonBG` | `string` |  |
| `buttonTextColor` | `string` |  |
| `height` | `number` |  |

**Usage:**

```tsx
<SECTIONHEROTEMP
  placeholder="…"
  placeholderColor="…"
  textColor="…"
  fontSize={0}
  textareaBG="…"
  borderColor="…"
  radius={0}
  buttonBG="…"
  buttonTextColor="…"
  height={0}
/>
```

### Logomatrix

**Usage:**

```tsx
<Logomatrix />
```

### Wehelpmake

**Variants:** `"Variant 1" | "Variant 2" | "Variant 3" | "Variant 4" | "phone 1" | "phone 2" | "phone 3" | "phone 4"`

**Props:**

| Name | Type | Required |
|---|---|---|
| `variant` | `WehelpmakeVariant | Partial<Record<"base" | "sm" | "md" | "lg" | "xl", Wehelp...` |  |
| `color1` | `string` |  |
| `color2` | `string` |  |

**Usage:**

```tsx
<Wehelpmake
  variant="Variant 1"
  color1="…"
  color2="…"
/>
```

_Variants also accept a per-breakpoint object, e.g._ `variant={{ base: '…', lg: '…' }}`

### Button4

**Variants:** `"Default" | "Loading" | "Disabled" | "Success" | "Error"`

**Props:**

| Name | Type | Required |
|---|---|---|
| `variant` | `Button4Variant | Partial<Record<"base" | "sm" | "md" | "lg" | "xl", Button4Va...` |  |

**Usage:**

```tsx
<Button4
  variant="Default"
/>
```

_Variants also accept a per-breakpoint object, e.g._ `variant={{ base: '…', lg: '…' }}`

### Navigation2

**Props:**

| Name | Type | Required |
|---|---|---|
| `stroke` | `string` |  |
| `width` | `number` |  |
| `dots` | `number` |  |

**Usage:**

```tsx
<Navigation2
  stroke="…"
  width={0}
  dots={0}
/>
```

### Brandsslider2

**Usage:**

```tsx
<Brandsslider2 />
```

### Wehelpmake2

**Variants:** `"Variant 1" | "Variant 2" | "Variant 3" | "Variant 4" | "phone 1" | "phone 2" | "phone 3" | "phone 4"`

**Props:**

| Name | Type | Required |
|---|---|---|
| `variant` | `Wehelpmake2Variant | Partial<Record<"base" | "sm" | "md" | "lg" | "xl", Wehel...` |  |
| `color1` | `string` |  |
| `color2` | `string` |  |

**Usage:**

```tsx
<Wehelpmake2
  variant="Variant 1"
  color1="…"
  color2="…"
/>
```

_Variants also accept a per-breakpoint object, e.g._ `variant={{ base: '…', lg: '…' }}`

### Imputslider

**Variants:** `"Variant 1" | "01" | "02" | "03" | "04" | "05" | "06" | "07" | "08" | "09" | "10" | "11" | "12" | "13" | "14"`

**Props:**

| Name | Type | Required |
|---|---|---|
| `variant` | `ImputsliderVariant | Partial<Record<"base" | "sm" | "md" | "lg" | "xl", Imput...` |  |

**Usage:**

```tsx
<Imputslider
  variant="Variant 1"
/>
```

_Variants also accept a per-breakpoint object, e.g._ `variant={{ base: '…', lg: '…' }}`

---

## Update to a newer export

When the designer re-exports in Framer, they'll share a new install URL. Apply it with either:

```bash
# option 1 — paste the new install line
npm install @proofly-framer/ui@<new-url>

# option 2 — helper CLI
npx @proofly-framer/update <new-export-id>
```

## More docs

- [Full integration guide](https://proofly.ae/docs/react-export/93bd9730-02e5-4beb-ba6a-885a45ba1894) — framework-specific setup (Next.js, Vite, Remix, Astro, CRA), polymorphic variants, customization patterns

---
<sub>Export ID: `93bd9730-02e5-4beb-ba6a-885a45ba1894`</sub>
